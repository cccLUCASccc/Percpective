chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startTimer") {
    setTimeout(() => {
      (async () => {
        // Nettoyage des données d'auth
        await chrome.storage.sync.remove("isAuthenticated");
        await chrome.storage.sync.remove("openParameters");

        // Récupérer la langue stockée
        const result = await chrome.storage.sync.get(['language']);
        const storedLanguage = result.language || 'en';

        // Notification de déconnexion
        chrome.notifications.create({
          type: "basic",
          iconUrl: "icons/icon_48.png",
          title: translations[storedLanguage]["notificationTitle"] || "Notification CyberProtect",
          message: translations[storedLanguage]["notificationMessage"] || "Vous avez été déconnecté(e) après 2 minutes d'inactivité."
        });

        // Tentative de fermeture de la popup (si elle est ouverte)
        chrome.runtime.sendMessage({ action: "closePopup" }, (response) => {
          if (chrome.runtime.lastError) {
            // La popup peut ne pas être ouverte : on ignore l'erreur.
            console.warn("Popup non ouverte :", chrome.runtime.lastError.message);
          }
        });
      })();
    }, 120000); // 2 minutes
  }
});
