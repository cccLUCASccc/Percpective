document.addEventListener('DOMContentLoaded', function () {
  const languageSelector = document.getElementById('language-selector');
  const toxicityInput = document.getElementById('toxicityThreshold');
  const thresholdValue = document.getElementById('threshold-value');

  // Récupérer la langue et la valeur du seuil de toxicité stockées dans le localStorage ou utiliser les valeurs par défaut
  chrome.storage.sync.get(['language', 'toxicityThreshold'], function (result) {
    const storedLanguage = result.language || 'en';
    const storedToxicityThreshold = result.toxicityThreshold || 50;

    if (languageSelector) {
      languageSelector.value = storedLanguage;
      translatePage(storedLanguage);
    }

    if (toxicityInput && thresholdValue) {
      toxicityInput.value = storedToxicityThreshold;
      thresholdValue.textContent = `${storedToxicityThreshold}%`;
    }
  });

  if (languageSelector) {
    languageSelector.addEventListener('change', function () {
      const lang = this.value;
      chrome.storage.sync.set({ language: lang }, function () {
        translatePage(lang);
      });
    });
  }

  if (toxicityInput) {
    toxicityInput.addEventListener('input', function () {
      const value = this.value;
      if (thresholdValue) {
        thresholdValue.textContent = `${value}%`;
      }
      chrome.storage.sync.set({ toxicityThreshold: value });
    });
  }

  function translatePage(lang) {
    console.log(`Translating page to ${lang}`);
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(element => {
      const key = element.getAttribute('data-i18n');
      if (translations[lang] && translations[lang][key]) {
        console.log(`Translating ${key} to ${translations[lang][key]}`);
        if (element.tagName === 'INPUT' && (element.type === 'text' || element.type === 'password')) {
          element.placeholder = translations[lang][key];
        } else {
          element.textContent = translations[lang][key];
        }
      } else {
        console.warn(`Translation for ${key} in ${lang} not found`);
      }
    });
  }
});
