document.addEventListener("DOMContentLoaded", async () => {
  const languageSelector = document.getElementById('language-selector');
  const toxicityInput = document.getElementById("toxicityThreshold");
  const thresholdValue = document.getElementById("threshold-value");

  // Récupérer la langue et la valeur du seuil de toxicité stockées dans le localStorage ou utiliser les valeurs par défaut
  chrome.storage.sync.get(['language'], function (result) {
    const storedLanguage = result.language || 'en';

    if (languageSelector) {
      languageSelector.value = storedLanguage;
      translatePage(storedLanguage);
    }
  });

  if (languageSelector) {
    languageSelector.addEventListener('change', function () {
      const lang = this.value;
      chrome.storage.sync.set({ language: lang }, function () {
        translatePage(lang);
      });
    });
  }

  if (toxicityInput) {
    toxicityInput.addEventListener('input', function () {
      const value = this.value;
      if (thresholdValue) {
        thresholdValue.textContent = `${value}%`;
      }
      chrome.storage.sync.set({ toxicityThreshold: value });
    });
  }

  loadBlockedSites(); // Chargement de la liste des sites bloqués

  // Chargement et setting des paramètres
  chrome.storage.sync.get(["consentGiven", "toxicityThreshold"], (result) => {
    if (typeof result.consentGiven !== "undefined") {
      const consentGivenCheckbox = document.getElementById("consentGiven");
      if (consentGivenCheckbox) {
        consentGivenCheckbox.checked = result.consentGiven;
      }
    }

    if (typeof result.toxicityThreshold !== "undefined") {
      const toxicityInput = document.getElementById("toxicityThreshold");
      const thresholdValue = document.getElementById("threshold-value");
      if (toxicityInput && thresholdValue) {
        toxicityInput.value = result.toxicityThreshold;
        thresholdValue.textContent = `${result.toxicityThreshold}%`;
      }
    }
  });

  // Gestion de l'affichage des div selon les différentes situations
  chrome.storage.sync.get("isAuthenticated", (authResult) => {
    if (authResult.isAuthenticated) {
      chrome.storage.sync.get("openParameters", (param) => {
        if (param.openParameters === true) {
          // Ouverture des Paramètres
          const setParamsDiv = document.getElementById("setParams");
          const getRightToAccessDiv = document.getElementById("getRightToAccess");
          const createPasswordDiv = document.getElementById("createPassword");
          const blockedSitesDiv = document.getElementById("blockedSites");
          if (setParamsDiv && getRightToAccessDiv && createPasswordDiv && blockedSitesDiv) {
            setParamsDiv.style.display = "none";
            getRightToAccessDiv.style.display = "none";
            createPasswordDiv.style.display = "block";
            blockedSitesDiv.style.display = "block";
          }
        } else {
          // L'utilisateur est authentifié
          const setParamsDiv = document.getElementById("setParams");
          const getRightToAccessDiv = document.getElementById("getRightToAccess");
          const createPasswordDiv = document.getElementById("createPassword");
          const blockedSitesDiv = document.getElementById("blockedSites");
          if (setParamsDiv && getRightToAccessDiv && createPasswordDiv && blockedSitesDiv) {
            setParamsDiv.style.display = "block";
            getRightToAccessDiv.style.display = "none";
            createPasswordDiv.style.display = "none";
            blockedSitesDiv.style.display = "none";
          }
        }
      });
    } else {
      // L'utilisateur n'est pas authentifié
      const setParamsDiv = document.getElementById("setParams");
      const blockedSitesDiv = document.getElementById("blockedSites");
      if (setParamsDiv && blockedSitesDiv) {
        setParamsDiv.style.display = "none";
        blockedSitesDiv.style.display = "none";
      }

      // Vérifie uniquement si le mot de passe administrateur existe
      chrome.storage.sync.get("adminPasswordHash", (passwordResult) => {
        const getRightToAccessDiv = document.getElementById("getRightToAccess");
        const createPasswordDiv = document.getElementById("createPassword");
        if (getRightToAccessDiv && createPasswordDiv) {
          if (passwordResult.adminPasswordHash) {
            // Le mot de passe existe
            getRightToAccessDiv.style.display = "block";
            createPasswordDiv.style.display = "none";
          } else {
            // Le mot de passe doit être créé
            getRightToAccessDiv.style.display = "none";
            createPasswordDiv.style.display = "block";
          }
        }
      });
    }
  });

  // Ajoute la version de l'extension
  const manifest = chrome.runtime.getManifest();
  const appVersion = document.getElementById("appVersion");
  if (appVersion) {
    appVersion.textContent = "V" + manifest.version;
  }

  // Ajustement de la valeur du % par rapport à la position du slider
  document.getElementById("toxicityThreshold").addEventListener("input", (event) => {
    const thresholdValue = document.getElementById("threshold-value");
    if (thresholdValue) {
      thresholdValue.textContent = `${event.target.value}%`;
    }
  });

  // Sauvegarde des paramètres
  document.getElementById("saveConsentAndSeuil").addEventListener("click", () => {
    const consentGiven = document.getElementById("consentGiven").checked;
    const toxicityThreshold = document.getElementById("toxicityThreshold").value;

    chrome.storage.sync.set(
      {
        consentGiven: consentGiven,
        toxicityThreshold: toxicityThreshold
      },
      () => {
        alert(translations[languageSelector.value]["saveSuccess"] || "Vos paramètres ont été sauvegardés !");
      }
    );
  });

  // Vérification si le texte contient une majuscule
  function containsUpperCase(str) {
    return /[A-Z]/.test(str);
  }

  // Vérification si le texte contient une minuscule
  function containsLowerCase(str) {
    return /[a-z]/.test(str);
  }

  // Vérification si le texte contient un caractère spécial
  function containsSpecial(str) {
    return /[-&@#§!%£*$=+~?\\]/.test(str);
  }

  // Soumission du mot de passe Administrateur et de la question secrète
  document.getElementById("save-password").addEventListener("click", async () => {
    const question = document.getElementById("secret-question").value.trim();
    const answer = document.getElementById("secret-answer").value.trim();
    const newPass = document.getElementById("new-password").value;
    const confirmPass = document.getElementById("confirm-password").value;
    if (!question || !answer) {
      document.getElementById("message").textContent = translations[languageSelector.value]["questionAnswerRequired"] || "⚠️ La question et la réponse secrètes doivent être renseignées.";
      return;
    }

    if (newPass !== confirmPass) {
      document.getElementById("message").textContent = translations[languageSelector.value]["passwordsDoNotMatch"] || "⚠️ Les mots de passe ne correspondent pas.";
      return;
    }

    if (newPass.length < 6 || !containsUpperCase(newPass) || !containsLowerCase(newPass) || !containsSpecial(newPass)) {
      document.getElementById("message").textContent = translations[languageSelector.value]["passwordRequirements"] || "⚠️ Le mot de passe doit contenir au moins 6 caractères, dont 1 majuscule, 1 minuscule et 1 caractère spécial.";
      return;
    }

    const hash = await hashPassword(newPass); // Le mot de passe haché
    const answerHash = await hashPassword(answer); // La réponse à la question secrète hachée

    const setParamsDiv = document.getElementById("setParams");
    const getRightToAccessDiv = document.getElementById("getRightToAccess");
    const createPasswordDiv = document.getElementById("createPassword");
    const blockedSitesDiv = document.getElementById("blockedSites");
    if (setParamsDiv && getRightToAccessDiv && createPasswordDiv && blockedSitesDiv) {
      setParamsDiv.style.display = "block";
      getRightToAccessDiv.style.display = "none";
      createPasswordDiv.style.display = "none";
      blockedSitesDiv.style.display = "none";
    }

    chrome.storage.sync.set({
      adminPasswordHash: hash,
      secretQuestion: question,
      secretAnswerHash: answerHash,
      isAuthenticated: true
    }, () => {
      alert(translations[languageSelector.value]["saveSuccess"] || "✅ Mot de passe et question secrète sauvegardés avec succès !");
      document.getElementById("new-password").value = "";
      document.getElementById("confirm-password").value = "";
      document.getElementById("secret-question").value = "";
      document.getElementById("secret-answer").value = "";
      try {
        chrome.storage.sync.remove("openParameters");
      } catch (error) {
        console.error("Erreur lors de la suppression de openParameters :", error);
      }
    });
  });

  // Annulation du changement du mot de passe Administrateur
  document.getElementById("cancel-password").addEventListener("click", async () => {
    chrome.storage.sync.remove("openParameters");
    const setParamsDiv = document.getElementById("setParams");
    const getRightToAccessDiv = document.getElementById("getRightToAccess");
    const createPasswordDiv = document.getElementById("createPassword");
    const blockedSitesDiv = document.getElementById("blockedSites");
    if (setParamsDiv && getRightToAccessDiv && createPasswordDiv && blockedSitesDiv) {
      setParamsDiv.style.display = "block";
      getRightToAccessDiv.style.display = "none";
      createPasswordDiv.style.display = "none";
      blockedSitesDiv.style.display = "none";
    }
  });

  // Annulation du changement de mot de passe en cas de perte de celui-ci
  document.getElementById("cancel-password2").addEventListener("click", async () => {
    location.reload();
  });

  // Chargement de la liste des sites bloqués
  function loadBlockedSites() {
    chrome.storage.sync.get("blockedSites", (data) => {
      const sitesObj = data.blockedSites || {};
      const list = document.getElementById("blocked-sites-list");
      if (list) {
        list.innerHTML = "";

        if (Object.keys(sitesObj).length === 0) {
          // Si aucun site bloqué n'est trouvé
          const emptyMessage = document.createElement("p");
          emptyMessage.textContent = translations[languageSelector.value]["noBlockedSites"] || "Aucun site bloqué.";
          emptyMessage.style.color = "gray";
          emptyMessage.style.fontStyle = "italic";
          list.appendChild(emptyMessage);
        } else {
          // Si des sites bloqués sont trouvés
          Object.entries(sitesObj).forEach(([site, details]) => {
            const li = document.createElement("li");
            li.textContent = `${site} ${details.manual ? '✋' : ''}`;

            const btn = document.createElement("button");
            btn.textContent = translations[languageSelector.value]["unblock"] || "Débloquer";
            btn.addEventListener("click", () => {
              delete sitesObj[site];
              chrome.storage.sync.set({ blockedSites: sitesObj }, () => {
                loadBlockedSites();
              });
            });

            li.appendChild(btn);
            list.appendChild(li);
          });
        }
      }
    });
  }

  // Blocage manuel d'un site
  document.getElementById("add-blocked-site-btn").addEventListener("click", () => {
    const input = document.getElementById("new-blocked-site");
    const newSite = input.value.trim();
    const domainRegex = /^(?!:\/\/)([a-zA-Z0-9-_]+\.)+[a-zA-Z]{2,11}?$/;

    if (!domainRegex.test(newSite)) {
      alert(translations[languageSelector.value]["invalidDomain"] || "⚠️ Veuillez entrer un domaine valide (ex: www.example.com)");
      return;
    }

    chrome.storage.sync.get(['blockedSites'], (result) => {
      const blockedSites = result.blockedSites || {};

      // Ajouter le nouveau site à la liste des sites bloqués avec :
      // - un timestamp,
      // - information de l'ajout manuel
      blockedSites[newSite] = { timestamp: Date.now(), manual: true };

      chrome.storage.sync.set({ blockedSites }, () => {
        loadBlockedSites();  // Mettre à jour la liste après l'ajout
        input.value = "";  // Effacer le champ de texte
      });
    });
  });

  // Hachage du mot de passe
  async function hashPassword(password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const buffer = await crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(buffer))
      .map(b => b.toString(16).padStart(2, "0"))
      .join("");
  }

  // Vérification du mot de passe saisi au login
  document.getElementById("submit").addEventListener("click", async () => {
    const password = document.getElementById("password").value;
    const storage = await chrome.storage.sync.get("adminPasswordHash");
    const inputHash = await hashPassword(password);
    if (inputHash === storage.adminPasswordHash) {
      await chrome.storage.sync.set({ isAuthenticated: true });
      // Activer le compteur pour déconnecter l'administrateur (voir background.js)
      chrome.runtime.sendMessage({ action: "startTimer" });
      const setParamsDiv = document.getElementById("setParams");
      const getRightToAccessDiv = document.getElementById("getRightToAccess");
      const createPasswordDiv = document.getElementById("createPassword");
      const blockedSitesDiv = document.getElementById("blockedSites");
      if (setParamsDiv && getRightToAccessDiv && createPasswordDiv && blockedSitesDiv) {
        setParamsDiv.style.display = "block";
        getRightToAccessDiv.style.display = "none";
        createPasswordDiv.style.display = "none";
        blockedSitesDiv.style.display = "none";
      }
    } else if (password.length === 0) {
      document.getElementById("message2").textContent = translations[languageSelector.value]["enterPassword"] || "⚠️ Veuillez saisir un mot de passe.";
    } else {
      document.getElementById("message2").textContent = translations[languageSelector.value]["incorrectPassword"] || "⚠️ Mot de passe incorrect.";
    }
  });

  // Événement qui déconnecte l'administrateur
  // sur clic du bouton "Déconnexion"
  document.getElementById("logout").addEventListener("click", logoutUser);

  // Fonction pour déconnecter l'administrateur
  async function logoutUser() {
    try {
      await chrome.storage.sync.remove("isAuthenticated");
      // alert("Vous êtes déconnecté(e)!");
      window.close();
    } catch (error) {
      console.error("Erreur lors de la déconnexion :", error);
    }
  }

  // Stocker l'état de la fenêtre des paramètres
  document.getElementById("open-options").addEventListener("click", async () => {
    await chrome.storage.sync.set({ openParameters: true });
  });

  // Définition du titre selon la création ou la modification du mot de passe Admin
  chrome.storage.sync.get("openParameters", (param) => {
    if (param.openParameters !== undefined && param.openParameters === true) {
      document.getElementById("titleChangePassword").textContent = translations[languageSelector.value]["modifyAdminPassword"] || "Modification du mot de passe Admin";
      document.getElementById("cancel-password").style.display = "block";
    } else {
      document.getElementById("titleChangePassword").textContent = translations[languageSelector.value]["createAdminPassword"] || "Création du mot de passe Admin";
      document.getElementById("cancel-password").style.display = "none";
    }
  });

  // Listener qui permet de fermer la popup à l'expiration du délai
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "closePopup") {
      window.close();
    }
  });

  // Ouvre le fichier README.md converti en HTML
  document.getElementById('open-readme').addEventListener('click', () => {
    chrome.tabs.create({
      url: chrome.runtime.getURL('readme.html') // ou 'readme.md' si tu veux le brut
    });
  });

  // Récupération du mot de passe via la question secrète
  document.getElementById("recover-password-link").addEventListener("click", () => {
    chrome.storage.sync.get(["secretQuestion"], (data) => {
      const question = data.secretQuestion;
      if (question) {
        document.getElementById("recovery-section").style.display = "block";
      } else {
        alert(translations[languageSelector.value]["noSecretQuestion"] || "⚠️ Aucune question secrète n'a été définie.");
      }
    });
  });

  // Validation de la réponse à la question secrète
  document.getElementById("submit-recovery-answer").addEventListener("click", async () => {
    const answer = document.getElementById("recovery-answer").value.trim();
    const answerHash = await hashPassword(answer);

    chrome.storage.sync.get(["secretAnswerHash"], (data) => {
      if (data.secretAnswerHash === answerHash) {
        alert(translations[languageSelector.value]["correctAnswer"] || "✅ Réponse correcte ! Vous pouvez maintenant modifier le mot de passe.");
        // Rediriger vers l'écran de modification du mot de passe
        const createPasswordDiv = document.getElementById("createPassword");
        const getRightToAccessDiv = document.getElementById("getRightToAccess");
        if (createPasswordDiv && getRightToAccessDiv) {
          createPasswordDiv.style.display = "block";
          getRightToAccessDiv.style.display = "none";
        }
      } else {
        alert(translations[languageSelector.value]["incorrectAnswer"] || "⚠️ Réponse incorrecte. Veuillez réessayer.");
      }
    });
  });

  function translatePage(lang) {
    console.log(`Translating page to ${lang}`);
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(element => {
      const key = element.getAttribute('data-i18n');
      if (translations[lang] && translations[lang][key]) {
        console.log(`Translating ${key} to ${translations[lang][key]}`);
        if (element.tagName === 'INPUT' && (element.type === 'text' || element.type === 'password')) {
          element.placeholder = translations[lang][key];
        } else {
          element.textContent = translations[lang][key];
        }
      } else {
        console.warn(`Translation for ${key} in ${lang} not found`);
      }
    });
  }
});
